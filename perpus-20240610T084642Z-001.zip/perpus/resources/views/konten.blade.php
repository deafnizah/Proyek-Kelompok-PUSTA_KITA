<!--awal KONTEN-->
<div class="col-md-9">
     @yield('isihalaman')                 
</div>
<!--akhir KONTEN-->
</div>
</div>